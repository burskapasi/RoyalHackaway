package com.example.communitykitchenfoodappwithnutritionalvalues;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Menu extends AppCompatActivity {
    DatabaseReference databaseRecipe;
    DatabaseReference weeklySchedule;
    ArrayList<Object> items = new ArrayList<>();
    final ArrayList<String> recipeList = new ArrayList<>(); // Create an ArrayList object
    private Spinner monSpinner;
    private Spinner tueSpinner;
    private Spinner wedSpinner;
    private Spinner thurSpinner;
    private Spinner friSpinner;
    private Button saveMenu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        databaseRecipe = FirebaseDatabase.getInstance().getReference("recipe");
        weeklySchedule = FirebaseDatabase.getInstance().getReference("weekly schedule");

        monSpinner =findViewById(R.id.spinnerMon);
        tueSpinner = findViewById(R.id.spinnerTue);
        wedSpinner = findViewById(R.id.spinnerWed);
        thurSpinner = findViewById(R.id.spinnerThur);
        friSpinner = findViewById(R.id.spinnerFri);
        saveMenu = findViewById(R.id.buttonSaveMenu);
        DisplayDataOnSpinner();
        Tuesday();
        Wednesday();
        Thursday();



    }
    public void DisplayDataOnSpinner(){


        databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
                for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                    recipeList.add(locationSnapshot.child("recipeName").getValue().toString());

                    //spinner 1
                    ArrayAdapter adapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, recipeList);
                    adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    monSpinner.setAdapter(adapter1);
                    //tueSpinner.setAdapter(adapter1);
                    //wedSpinner.setAdapter(adapter1);
                    //thurSpinner.setAdapter(adapter1);
                    friSpinner.setAdapter(adapter1);
                    monSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view,
                                                   int position, long id) {
                            Object item = adapterView.getItemAtPosition(position);
                            if (item != null) {
                                Toast.makeText(Menu.this, item.toString(),
                                        Toast.LENGTH_SHORT).show();
                            }
                            SaveDataUsingButton(item);

                            Toast.makeText(Menu.this, "Selected",
                                    Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                            // TODO Auto-generated method stub

                        }
                    });
                }

                }


            @Override
            public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

            }
        });
    }

    public void SaveDataUsingButton(final Object item){

        saveMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = weeklySchedule.push().getKey();
                items.add(item);
                weeklySchedule.child(id).child("Monday").setValue(item);
                weeklySchedule.child(id).child("Tuesday").setValue(item);
                weeklySchedule.child(id).child("Wednesday").setValue(item);
                weeklySchedule.child(id).child("Thursday").setValue(item);





                System.out.println(item);

            }
        });
    }
public void Thursday(){

    databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

        @Override
        public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
            for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                recipeList.add(locationSnapshot.child("recipeName").getValue().toString());

                //spinner 1
                ArrayAdapter adapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, recipeList);
                adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                thurSpinner.setAdapter(adapter1);
                thurSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view,
                                               int position, long id) {
                        Object item = adapterView.getItemAtPosition(position);
                        if (item != null) {
                            Toast.makeText(Menu.this, item.toString(),
                                    Toast.LENGTH_SHORT).show();
                        }
                        SaveDataUsingButton(item);

                        Toast.makeText(Menu.this, "Selected",
                                Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                        // TODO Auto-generated method stub

                    }
                });
            }

        }


        @Override
        public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

        }
    });
}
    public void Tuesday(){

        databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
                for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                    recipeList.add(locationSnapshot.child("recipeName").getValue().toString());

                    //spinner 1
                    ArrayAdapter adapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, recipeList);
                    adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    tueSpinner.setAdapter(adapter1);
                    tueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view,
                                                   int position, long id) {
                            Object item = adapterView.getItemAtPosition(position);
                            if (item != null) {
                                Toast.makeText(Menu.this, item.toString(),
                                        Toast.LENGTH_SHORT).show();
                            }
                            SaveDataUsingButton(item);

                            Toast.makeText(Menu.this, "Selected",
                                    Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                            // TODO Auto-generated method stub

                        }
                    });
                }

            }


            @Override
            public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

            }
        });
    }

    public void Wednesday(){

        databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
                for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                    recipeList.add(locationSnapshot.child("recipeName").getValue().toString());

                    //spinner 1
                    ArrayAdapter adapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, recipeList);
                    adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    wedSpinner.setAdapter(adapter1);
                    wedSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view,
                                                   int position, long id) {
                            Object item = adapterView.getItemAtPosition(position);
                            if (item != null) {
                                Toast.makeText(Menu.this, item.toString(),
                                        Toast.LENGTH_SHORT).show();
                            }
                            SaveDataUsingButton(item);

                            Toast.makeText(Menu.this, "Selected",
                                    Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                            // TODO Auto-generated method stub

                        }
                    });
                }

            }


            @Override
            public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

            }
        });
    }

    }
