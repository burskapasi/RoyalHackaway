package com.example.communitykitchenfoodappwithnutritionalvalues;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
private Button button;
private Button insertButton;
private Button setMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toast.makeText(MainActivity.this, "Firebase connection success", Toast.LENGTH_LONG).show();
        button = findViewById(R.id.menuButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            openActivityMenu();
            }
        });

        insertButton = findViewById(R.id.insertButton);
        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertActivityMenu();
            }
        });
        setMenu = findViewById(R.id.setMenuButton);
        setMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setMenuActivity();
            }
        });

    }

    private void setMenuActivity() {
        Intent intent = new Intent(this, Menu.class);
        startActivity(intent);
    }

    public void openActivityMenu(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    public void insertActivityMenu(){
        Intent intent = new Intent(this, NutritionalValues.class);
        startActivity(intent);
    }

}
