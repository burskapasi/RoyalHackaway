package com.example.communitykitchenfoodappwithnutritionalvalues;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Dashboard extends AppCompatActivity {

    ImageButton foodImageButton;
    ImageButton monthlyMenuButton;
    ImageButton profileButton;
    ImageButton ratingButton;
    TextView announcement;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        //Announcement TextView
        announcement = findViewById(R.id.textViewAnnouncement);

        // Order Button
        foodImageButton = findViewById(R.id.imageButtonOrder);
        foodImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityOrder();
                Toast.makeText(Dashboard.this, "Order Food", Toast.LENGTH_LONG).show();
            }
        });

        //imageButtonMonthlyMenu
        monthlyMenuButton = findViewById(R.id.imageButtonMonthlyMenu);
        monthlyMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityMonthlyMenu();
                Toast.makeText(Dashboard.this, "Monthly Menu", Toast.LENGTH_LONG).show();
            }
        });

        //imageButtonProfile
        profileButton = findViewById(R.id.imageButtonProfile);
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityProfile();
                Toast.makeText(Dashboard.this, "Profile", Toast.LENGTH_LONG).show();
            }
        });
        //imageButtonRating
        ratingButton = findViewById(R.id.imageButtonRating);
        ratingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityReview();
                Toast.makeText(Dashboard.this, "Rating", Toast.LENGTH_LONG).show();
            }
        });


    }
    public void openActivityOrder(){
        Intent intent = new Intent(this, OrderPage.class);
        startActivity(intent);
    }
    public void openActivityMonthlyMenu(){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }
    public void openActivityProfile(){
        Intent intent = new Intent(this, ProfilePage.class);
        startActivity(intent);
    }
    public void openActivityReview(){
        Intent intent = new Intent(this, Rating.class);
        startActivity(intent);
    }
    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();//logout
        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
        finish();
    }

}
