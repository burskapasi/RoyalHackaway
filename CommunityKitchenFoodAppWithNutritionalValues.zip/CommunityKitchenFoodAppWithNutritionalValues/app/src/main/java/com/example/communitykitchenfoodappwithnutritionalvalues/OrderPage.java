package com.example.communitykitchenfoodappwithnutritionalvalues;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OrderPage extends AppCompatActivity {
    private RecyclerView recyclerView;
    DatabaseReference databaseRecipe;
    List<ModelClass> recipeList = new ArrayList<>();
    private Spinner spinner;
    private Button saveButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        databaseRecipe = FirebaseDatabase.getInstance().getReference("recipe");

        spinner = findViewById(R.id.spinnerQuantity);
        saveButton = findViewById(R.id.saveButton);
        //Prints Data from Database and displays on recycler view
        readData();
        SaveButton();




    }
//doesnt work goes to null
    private void SaveButton() {

        if(saveButton == null){
            System.out.println("did not work");
        }else{
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String text = spinner.getSelectedItem().toString();
                    System.out.println(text);



                }
            });
        }
    }

    public void readData(){
        databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
                for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                    recipeList.add(new ModelClass(R.drawable.ic_launcher_background,
                            locationSnapshot.child("recipeName").getValue().toString(),
                            "| Energy: " + locationSnapshot.child("energy").getValue().toString() +
                                    "| Fat: " + locationSnapshot.child("fat").getValue().toString() +
                                    "| Saturation: " + locationSnapshot.child("saturates").getValue().toString() +
                                    "| Sugar" + locationSnapshot.child("sugar").getValue().toString() +
                                    "| Salt" + locationSnapshot.child("salt").getValue().toString()));
                    Adapter adapter = new Adapter(recipeList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    Log.d("recipe updated", "recipe: " + recipeList); //log

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

            }
        });
    }
}
