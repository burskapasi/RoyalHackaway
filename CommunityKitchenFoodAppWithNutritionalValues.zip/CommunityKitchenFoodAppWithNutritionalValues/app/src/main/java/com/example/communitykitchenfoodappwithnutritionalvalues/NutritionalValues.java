package com.example.communitykitchenfoodappwithnutritionalvalues;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class NutritionalValues extends AppCompatActivity {

   private  EditText inpRecipeName,inpEnergy, inpFat, inpSaturates, inpSugars, inpSalt;
   private Button saveButton;
   DatabaseReference databaseRecipe;
   private TextView read;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutritional_values);

        read =findViewById(R.id.read);

        databaseRecipe = FirebaseDatabase.getInstance().getReference("recipe");






        inpRecipeName = findViewById(R.id.recipeNameEditText);
        inpEnergy = findViewById(R.id.energyEditText);
        inpFat = findViewById(R.id.fatEditText);
        inpSaturates = findViewById(R.id.saturatesEditText);
        inpSugars = findViewById(R.id.sugarEditText);
        inpSalt = findViewById(R.id.saltEditText);
        saveButton = findViewById(R.id.saveButton);
        read = findViewById(R.id.read);


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


//                HashMap<Integer,String> insertValues=new HashMap<>();
//                insertValues.put(1,inpRecipeName.getText().toString());
//                insertValues.put(2,inpEnergy.getText().toString()+"KJ");
//                insertValues.put(3,inpFat.getText().toString()+"g");
//                insertValues.put(4,inpSaturates.getText().toString()+"g");
//                insertValues.put(5,inpSugars.getText().toString()+"g");
//                insertValues.put(6,inpSalt.getText().toString()+"g");


                //Toast.makeText(NutritionalValues.this,insertValues.toString(), Toast.LENGTH_LONG).show();
                AddRecipe();
                ClearRecipeText();
                readData();

//                ValueEventListener recipeListener = new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        // Get Post object and use the values to update the UI
//                        RecipeNV post = dataSnapshot.getValue(RecipeNV.class);
//                        // ...
//                        System.out.println("onDataChange: " + post.recipeName);
//
//
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        // Getting Post failed, log a message
//                        // ...
//                    }
//                };
//                databaseRecipe.addValueEventListener(recipeListener);

            }
        });


    }
    public void AddRecipe(){
        String recipeName =inpRecipeName.getText().toString().trim();
        String energy = inpEnergy.getText().toString().trim();
        String fat = inpFat.getText().toString().trim();
        String saturates =inpSaturates.getText().toString();
        String sugar = inpSugars.getText().toString().trim();
        String salt = inpSalt.getText().toString().trim();

        if (!TextUtils.isEmpty(recipeName)){
           String id = databaseRecipe.push().getKey();
           RecipeNV recipenv = new RecipeNV(recipeName, energy,fat,saturates,sugar,salt);

           databaseRecipe.child(id).setValue(recipenv);
           Toast.makeText(this,"Recipe added", Toast.LENGTH_LONG).show();

        }else{
            Toast.makeText(this, "You Should enter a recipe name", Toast.LENGTH_SHORT).show();
        }
    }
    public void ClearRecipeText(){
        inpRecipeName.setText(" ");
        inpEnergy.setText(" ");
        inpFat.setText(" ");
        inpSaturates.setText(" ");
        inpSugars.setText(" ");
        inpSalt.setText(" ");

    }
    public void readData(){
        final ArrayList<String> recipeList = new ArrayList<String>();
        databaseRecipe.addValueEventListener(new ValueEventListener() { //attach listener

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //something changed!
                for (DataSnapshot locationSnapshot : dataSnapshot.getChildren()) {
                    recipeList.add(locationSnapshot.child("recipeName").getValue().toString());
                    recipeList.add(locationSnapshot.child("energy").getValue().toString());
                    recipeList.add(locationSnapshot.child("fat").getValue().toString());
                    recipeList.add(locationSnapshot.child("saturates").getValue().toString());
                    recipeList.add(locationSnapshot.child("sugar").getValue().toString());
                    recipeList.add(locationSnapshot.child("salt").getValue().toString());

                    Log.d("recipe updated", "location: " + recipeList); //log
                   // read.setText("hi");

                    for (int i = 0; i < recipeList.size(); i++) {
                        read.setText(recipeList.get(i));
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) { //update UI here if error occurred.

            }
        });
    }
}
