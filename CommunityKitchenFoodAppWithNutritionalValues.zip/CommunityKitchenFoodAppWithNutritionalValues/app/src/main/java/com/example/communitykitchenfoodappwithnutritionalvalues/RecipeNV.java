package com.example.communitykitchenfoodappwithnutritionalvalues;

public class RecipeNV {
    String recipeName;
    String energy;
    String fat;
    String saturates;
    String sugar;
    String salt ;



    public RecipeNV(){

    }
    public RecipeNV(String recipeName, String energy, String fat, String saturates, String sugar, String salt) {
        this.recipeName = recipeName;
        this.energy = energy;
        this.fat = fat;
        this.saturates = saturates;
        this.sugar = sugar;
        this.salt = salt;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public String getEnergy() {
        return energy;
    }

    public String getFat() {
        return fat;
    }

    public String getSaturates() {
        return saturates;
    }

    public String getSugar() {
        return sugar;
    }

    public String getSalt() {
        return salt;
    }
}
